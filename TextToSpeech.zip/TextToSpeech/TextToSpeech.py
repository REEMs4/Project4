{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "1cc7c403",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: ibm_watson in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (5.2.2)\n",
      "Requirement already satisfied: ibm-cloud-sdk-core==3.*,>=3.3.6 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_watson) (3.10.1)\n",
      "Requirement already satisfied: python-dateutil>=2.5.3 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_watson) (2.8.1)\n",
      "Requirement already satisfied: requests<3.0,>=2.0 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_watson) (2.25.1)\n",
      "Requirement already satisfied: websocket-client==1.1.0 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_watson) (1.1.0)\n",
      "Requirement already satisfied: PyJWT<3.0.0,>=2.0.1 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm-cloud-sdk-core==3.*,>=3.3.6->ibm_watson) (2.1.0)\n",
      "Requirement already satisfied: six>=1.5 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from python-dateutil>=2.5.3->ibm_watson) (1.15.0)\n",
      "Requirement already satisfied: urllib3<1.27,>=1.21.1 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.0->ibm_watson) (1.26.4)\n",
      "Requirement already satisfied: idna<3,>=2.5 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.0->ibm_watson) (2.10)\n",
      "Requirement already satisfied: chardet<5,>=3.0.2 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.0->ibm_watson) (4.0.0)\n",
      "Requirement already satisfied: certifi>=2017.4.17 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.0->ibm_watson) (2020.12.5)\n",
      "Note: you may need to restart the kernel to use updated packages.\n"
     ]
    }
   ],
   "source": [
    "pip install ibm_watson"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "d048a954",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: ibm_cloud_sdk_core in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (3.10.1)\n",
      "Requirement already satisfied: requests<3.0,>=2.20 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_cloud_sdk_core) (2.25.1)\n",
      "Requirement already satisfied: python-dateutil<3.0.0,>=2.5.3 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_cloud_sdk_core) (2.8.1)\n",
      "Requirement already satisfied: PyJWT<3.0.0,>=2.0.1 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_cloud_sdk_core) (2.1.0)\n",
      "Requirement already satisfied: six>=1.5 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from python-dateutil<3.0.0,>=2.5.3->ibm_cloud_sdk_core) (1.15.0)\n",
      "Requirement already satisfied: urllib3<1.27,>=1.21.1 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.20->ibm_cloud_sdk_core) (1.26.4)\n",
      "Requirement already satisfied: certifi>=2017.4.17 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.20->ibm_cloud_sdk_core) (2020.12.5)\n",
      "Requirement already satisfied: idna<3,>=2.5 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.20->ibm_cloud_sdk_core) (2.10)\n",
      "Requirement already satisfied: chardet<5,>=3.0.2 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.20->ibm_cloud_sdk_core) (4.0.0)\n",
      "Note: you may need to restart the kernel to use updated packages.\n"
     ]
    }
   ],
   "source": [
    "pip install ibm_cloud_sdk_core"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "c44962e2",
   "metadata": {},
   "outputs": [],
   "source": [
    "from ibm_watson import TextToSpeechV1"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "6fde62a8",
   "metadata": {},
   "outputs": [],
   "source": [
    "from ibm_cloud_sdk_core.authenticators import IAMAuthenticator"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "ff7838d2",
   "metadata": {},
   "outputs": [],
   "source": [
    "api = IAMAuthenticator(\"HLU6dzAO8LmVJfSSknwho-vWGVn0Y9Z8F4YaJ2mIppvW\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "id": "b157084c",
   "metadata": {},
   "outputs": [],
   "source": [
    "text_2_speech = TextToSpeechV1(authenticator = api)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "id": "ce44b78c",
   "metadata": {},
   "outputs": [],
   "source": [
    "text_2_speech.set_service_url(\"https://api.eu-gb.text-to-speech.watson.cloud.ibm.com/instances/53d6a8bb-2aff-47c5-b7fe-b69c3b0656fb\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 34,
   "id": "75770b8e",
   "metadata": {},
   "outputs": [],
   "source": [
    "with open(\"Welcome1.txt\") as text_file:\n",
    "    data = text_file.read()\n",
    "    text_file.close()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 42,
   "id": "d1b9e405",
   "metadata": {},
   "outputs": [],
   "source": [
    "with open(\"demo.mp3\",\"wb\") as audio:\n",
    "    audio.write(text_2_speech.synthesize(data,accept = \"audio/mp3\", voice = \"en-US_AllisonV2Voice\").get_result().content)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "b671fbe7",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
