{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "90864d25",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: ibm_watson in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (5.2.2)Note: you may need to restart the kernel to use updated packages.\n",
      "Requirement already satisfied: python-dateutil>=2.5.3 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_watson) (2.8.1)\n",
      "Requirement already satisfied: websocket-client==1.1.0 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_watson) (1.1.0)\n",
      "Requirement already satisfied: ibm-cloud-sdk-core==3.*,>=3.3.6 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_watson) (3.10.1)\n",
      "Requirement already satisfied: requests<3.0,>=2.0 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_watson) (2.25.1)\n",
      "Requirement already satisfied: PyJWT<3.0.0,>=2.0.1 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm-cloud-sdk-core==3.*,>=3.3.6->ibm_watson) (2.1.0)\n",
      "Requirement already satisfied: six>=1.5 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from python-dateutil>=2.5.3->ibm_watson) (1.15.0)\n",
      "Requirement already satisfied: idna<3,>=2.5 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.0->ibm_watson) (2.10)\n",
      "Requirement already satisfied: certifi>=2017.4.17 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.0->ibm_watson) (2020.12.5)\n",
      "Requirement already satisfied: urllib3<1.27,>=1.21.1 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.0->ibm_watson) (1.26.4)\n",
      "Requirement already satisfied: chardet<5,>=3.0.2 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.0->ibm_watson) (4.0.0)\n",
      "\n"
     ]
    }
   ],
   "source": [
    "pip install ibm_watson"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "55d80b70",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Requirement already satisfied: ibm_cloud_sdk_core in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (3.10.1)\n",
      "Requirement already satisfied: python-dateutil<3.0.0,>=2.5.3 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_cloud_sdk_core) (2.8.1)\n",
      "Requirement already satisfied: PyJWT<3.0.0,>=2.0.1 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_cloud_sdk_core) (2.1.0)\n",
      "Requirement already satisfied: requests<3.0,>=2.20 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from ibm_cloud_sdk_core) (2.25.1)\n",
      "Requirement already satisfied: six>=1.5 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from python-dateutil<3.0.0,>=2.5.3->ibm_cloud_sdk_core) (1.15.0)\n",
      "Requirement already satisfied: idna<3,>=2.5 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.20->ibm_cloud_sdk_core) (2.10)\n",
      "Requirement already satisfied: certifi>=2017.4.17 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.20->ibm_cloud_sdk_core) (2020.12.5)\n",
      "Requirement already satisfied: urllib3<1.27,>=1.21.1 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.20->ibm_cloud_sdk_core) (1.26.4)\n",
      "Requirement already satisfied: chardet<5,>=3.0.2 in c:\\users\\re-x5\\anaconda3\\lib\\site-packages (from requests<3.0,>=2.20->ibm_cloud_sdk_core) (4.0.0)\n",
      "Note: you may need to restart the kernel to use updated packages.\n"
     ]
    }
   ],
   "source": [
    "pip install ibm_cloud_sdk_core"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "e58c37fd",
   "metadata": {},
   "outputs": [],
   "source": [
    "from ibm_watson import SpeechToTextV1"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "5e42738c",
   "metadata": {},
   "outputs": [],
   "source": [
    "from ibm_cloud_sdk_core.authenticators import IAMAuthenticator"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "db5471d5",
   "metadata": {},
   "outputs": [],
   "source": [
    "api = IAMAuthenticator(\"Z06toWwAXr6sQnZsNx_8jARA6PfanVYiLFvHcdJe-rLm\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "af20ada4",
   "metadata": {},
   "outputs": [],
   "source": [
    "speech_2_text = SpeechToTextV1(authenticator = api)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "id": "2e8ab1d8",
   "metadata": {},
   "outputs": [],
   "source": [
    "speech_2_text.set_service_url(\"https://api.eu-gb.speech-to-text.watson.cloud.ibm.com/instances/9928c108-cf44-4b45-9f6d-33142869d695\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "id": "d249a838",
   "metadata": {},
   "outputs": [],
   "source": [
    "with open(\"demo.mp3\",\"rb\") as audio_file:\n",
    "    result = speech_2_text.recognize(\n",
    "    audio = audio_file, content_type = \"audio/mp3\"\n",
    "    ).get_result()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "id": "434c0a49",
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "{'result_index': 0, 'results': [{'final': True, 'alternatives': [{'transcript': 'hello gorgeous ', 'confidence': 0.99}]}, {'final': True, 'alternatives': [{'transcript': 'welcome to my page ', 'confidence': 0.99}]}]}\n"
     ]
    }
   ],
   "source": [
    "print(result)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "ecc82542",
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
